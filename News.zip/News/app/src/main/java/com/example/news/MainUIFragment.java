package com.example.news;

import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;


import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;


public class MainUIFragment  extends Fragment {
    private Activity containerActivity; // Activity to which this fragment is contained in
    private FragmentTransaction fragTransaction; // Reference to the fragmentTransaction

    // The following group of Strings are used to perform an api request to newsapi to search for
    // news sources regarding a search term
    private String apiURL = "https://newsapi.org/v2/everything?sortBy=publishedAt&q=";
    private String endURL = "&from=";
    private String dateURL ;
    private String closeURL= "&apiKey=6cfd91a80bdb45fabcecc94e23e581e1";
    private String searchTerm = "";
    // ********************
    //  <------- END URL REQUEST REFERENCES ------->

    private ListView articleListView; // ListView reference to attach content to

    private ArrayAdapter<String> articleArrayAdapter = null; // ArrayAdapter used to set Listview
    private ArrayList<String> sources = new ArrayList<String>(); // String of all sources from search
    private ArrayList<String> articles = new ArrayList<String>(); // String of all articles from search
    private ArrayList<String> URLS = new ArrayList<String>();// String of all URLS from search
    private ArrayList<String> content = new ArrayList<String>();// String of all content from search


    private String urlToOpen; // Current URL for content shown if button clicked
    private String articleContents; // Current content shown if button clicked
    private String articleSource;// Current article Source for content shown if button clicked

    /**
     * Constructor to create a fragment will also grab the current time and set it for the
     * necessary search term
     */
    public MainUIFragment () {
        String currentDate = getCalculatedDate("yyyy-MM-dd", -7);
        dateURL = currentDate;
    }

    /**
     * This method was found on stackoverflow.com it was written by Pratik Butani but it will
     * return a string of the current date with the given offset by the parameter days an int
     * @param dateFormat String of the format needed to be returned
     * @param days offset of current date
     * @return
     */
    public static String getCalculatedDate(String dateFormat, int days) {
        Calendar cal = Calendar.getInstance();
        SimpleDateFormat s = new SimpleDateFormat(dateFormat);
        cal.add(Calendar.DAY_OF_YEAR, days);
        return s.format(new Date(cal.getTimeInMillis()));
    }

    /**
     *
     * @return String fro the webUrl to open for the content that is currently selected
     */
    public String getCurrentURL(){
        return urlToOpen;
    }


    /**
     * This method will be used to set refernces to the proper activity and FragmentTransaction to
     * reference
     * @param containerActivity Activity refernce to the activity in which this is stored
     * @param fragTrans FragmentTransaction to reference the one that was created in the view that
     *                  called this function
     */
    public void setContainerActivity(Activity containerActivity, FragmentTransaction fragTrans) {
        this.containerActivity = containerActivity;
        this.fragTransaction = fragTrans;
    }

    /**
     * This method will reset the arrayList items to new refernces as they will need to be
     * populated with their own specific information
     * @param searchTerm String to the new search term that was selected
     */
    public void newSearchRequest(String searchTerm){
        this.searchTerm = searchTerm;
        articles = new ArrayList<String>();
        content = new ArrayList<String>();
        sources = new ArrayList<String>();
        URLS = new ArrayList<String>();
        new DownloadArticles().execute();
        articleArrayAdapter = new ArrayAdapter<String>(containerActivity, R.layout.layout_resource,
                R.id.articleTextView, articles);
        articleListView.setAdapter(articleArrayAdapter);
        articleListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                urlToOpen = URLS.get(position);
                articleContents = content.get(position);
                articleSource = sources.get(position);
                ArticleFragment openArticle = new ArticleFragment(articleContents, articleSource);
                fragTransaction = getActivity().getSupportFragmentManager().beginTransaction();
                fragTransaction.replace(R.id.outerMostLinearLayout, openArticle);
                fragTransaction.addToBackStack(null);
                fragTransaction.commit();
            }
        });
    }

    /**
     * Override method used to set the layout and attach the arrayAdapter to the listView and return
     * the view that we created
     * When this fragment is created this method will set the listview clickListener to on in order
     * to see which button was pushed and appropriatley grab the coresponding content to that
     * specific button
     * @param inflater LayoutInflater used to inflate the layout
     * @param container ViewGroup of where the view is contained
     * @param savedInstanceState Bundle of the instance state
     * @return
     */
    @Override
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.main_fragment, container, false);
        articleListView = v.findViewById(R.id.articleList);
        try {
            new DownloadArticles().execute();
            articleArrayAdapter = new ArrayAdapter<String>(containerActivity, R.layout.layout_resource,
                    R.id.articleTextView, articles);
            articleListView.setAdapter(articleArrayAdapter);
            articleListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    urlToOpen = URLS.get(position);
                    articleContents = content.get(position);
                    articleSource = sources.get(position);
                    ArticleFragment openArticle = new ArticleFragment(articleContents, articleSource);
                    fragTransaction = getActivity().getSupportFragmentManager().beginTransaction();
                    fragTransaction.replace(R.id.outerMostLinearLayout, openArticle);
                    fragTransaction.addToBackStack(null);
                    fragTransaction.commit();
                                                       }
                                                   });
            return v;
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }


    /**
     *
     * This class will be used to querey a a new search term with results to populate
     * the ListView in UI with new data
     */
    public class DownloadArticles extends AsyncTask<Object, Void, JSONObject> {
        @Override
        protected JSONObject doInBackground(Object[] objects) {
            try {
                String json = "" ;
                String line;
                URL url = new URL(apiURL +searchTerm+endURL+dateURL+closeURL);
                BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));
                while ((line = in.readLine()) != null) {
                    json += line;
                }
                JSONObject jsonObject = new JSONObject(json);
                in.close();
                return jsonObject;
            } catch (Exception e) { e.printStackTrace(); }
            return null;
        }

        /**
         * This method will be used to mine data from the url that was sent to flickr to recieve
         * access to public photos in order to process requests
         * @param articleJSON JSONObject from the api request sent
         */
        @Override
        protected void onPostExecute(JSONObject articleJSON) {
            try {
                JSONArray articleArray =  articleJSON.getJSONArray("articles");
                for (int i = 0; i< articleArray.length();i++) {
                    JSONObject source = articleArray.getJSONObject(i).getJSONObject("source");
                    articles.add(source.getString("name")+"\n\t\t\t\t"+articleArray.getJSONObject(i).getString("author"));
                    sources.add(source.getString("name"));
                    URLS.add(articleArray.getJSONObject(i).getString("url"));
                    content.add(articleArray.getJSONObject(i).getString("content"));
                }
                articleArrayAdapter.notifyDataSetChanged();
            }
            catch (Exception e){
                e.printStackTrace();
            }
        }
    }

}
