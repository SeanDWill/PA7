package com.example.news;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

/**
 * Name: Sean Williams
 * Course: CSC 317
 * Instructor: Ben Dicken
 * This activity will call fragments to query search result of news articles and read them and
 * also allow to open the original post from their website
 */
public class MainActivity extends AppCompatActivity {

    private FragmentTransaction fragTransition; // FragmentTransaction used to manage new fragments
    private EditText searchEdit; // EditText of the search Term
    private String searchText; // String reference to the search term
    private MainUIFragment currentFragment; // The main fragment used in this app
    private OpenWebViewFragment currenWebFragment; // a possible webview fragment to be made
    private String url; // URL to open in a webView if called
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        searchEdit = findViewById(R.id.searchField);
        currentFragment = new MainUIFragment();
        currentFragment.setContainerActivity(this, fragTransition);
        fragTransition = getSupportFragmentManager().beginTransaction();
        fragTransition.replace(R.id.outerMostLinearLayout, currentFragment);
        fragTransition.addToBackStack(null);
        fragTransition.commit();
    }

    /**
     * This method will call on the current fragment to query a new search with a new search term
     * @param v not needed or used but is the "Search" Button item being clicked
     */
    public void articleSearch(View v){
        searchEdit = findViewById(R.id.searchField);
        searchText = searchEdit.getText().toString();
        currentFragment.newSearchRequest(searchText);
    }

    /**
     * This method is called when a button in the article contents is selected where all the data
     * that is needed to open the URL is encapulated in that Fragment "currentFragment" where we
     * call the method to getCurrentURL to get the string of which to topen and create a fragment
     * with that String given in the constructor
     * @param v not needed or used but is the "Read On" Button item being clicked
     */
    public void articleOpen(View v){
        url = currentFragment.getCurrentURL();
        currenWebFragment = new OpenWebViewFragment(url);
        fragTransition = getSupportFragmentManager().beginTransaction();
        fragTransition.replace(R.id.outerMostLinearLayout, currenWebFragment);
        fragTransition.addToBackStack(null);
        fragTransition.commit();
    }
}
