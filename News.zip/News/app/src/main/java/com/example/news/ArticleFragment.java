package com.example.news;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.fragment.app.Fragment;


public class ArticleFragment extends Fragment {
    TextView contents; // TextView reference to set the contents that were sent to this fragment
    TextView source;    // TextView reference to set the source that was sent to this fragment
    private String setContents; //Contents from article to display
    private String articleSource; // Source from which the content is from


    /**
     * Constructor needed to create the fragment
     * @param setContents String of the contents that belong to the article selected
     * @param articleSource String of the source of the information
     */
    public ArticleFragment(String setContents, String articleSource){
        this.setContents = setContents;
        this.articleSource = articleSource;
    }

    /**
     * @param inflater LayoutInflater used to inflate the layout
     * @param container ViewGroup of where the view is contained
     * @param savedInstanceState Bundle of the instance state
     * @return v the view that is created
     */
    @Override
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.article_fragment, container, false);
        contents = v.findViewById(R.id.articleContentText);
        source = v.findViewById(R.id.articleNameText);
        source.setText(articleSource);
        contents.setText(setContents);
        return v;
    }


}
