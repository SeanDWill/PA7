package com.example.news;

import android.app.Activity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;

import androidx.fragment.app.Fragment;

public class OpenWebViewFragment extends Fragment {

    private String urlToOpen; // URL to open

    /**
     *
     * @param urlToOpen String of the URL to open
     */
    public OpenWebViewFragment(String urlToOpen){
        this.urlToOpen = urlToOpen;
    }

    /** Opens a webView of a URL
     * @param inflater LayoutInflater used to inflate the layout
     * @param container ViewGroup of where the view is contained
     * @param savedInstanceState Bundle of the instance state
     * @return v View of the view that was created
     */
    @Override
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.web_fragment, container, false);
        WebView myWebView = v.findViewById(R.id.webView);
        myWebView.loadUrl(urlToOpen);
        return v;
    }
}
